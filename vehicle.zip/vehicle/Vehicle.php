<?php

namespace Company;

include_once 'VehicleInterface.php';

use Company\VehicleInterface;

abstract class Vehicle implements VehicleInterface
{
  /**
   * @var string
   */
  private $color;

  /**
   * @var int
   */
  private $speed = 0;

  /**
   * @var string
   */
  private $chasisNumber;

  /**
   * @var object[]
   */
  private $data = [];

  /**
   * @var int
   */
  protected $topSpeed = 0;

  /**
   * @param string $rgb
   */
  public function setColor(string $rgb)
  {
    $this->color = $rgb;
  }

  /**
   * @param string $chasisNumber
   */
  public function setChasisNumber(string $chasisNumber)
  {
    $this->chasisNumber = $chasisNumber;
  }

  /**
   * @param $key
   */
  public function getPart($key)
  {
    return $this->data[$key];
  }

  /**
   * @param string $key
   * @param object $value
   */
  public function setPart($key, $value)
  {
    $this->data[$key] = $value;
  }

  /**
   * @param void
   */
  public function getParts()
  {
    return $this->data;
  }

  /**
   * @param void
   */
  public function getSpeed()
  {
    return $this->speed;
  }

  public function speedUp(int $increment)
  {
    if (($this->speed + $increment) <= $this->topSpeed)
    {
      $this->speed += $increment;
    }
    else
    {
      $this->speed = $this->topSpeed;
    }
    echo "Speed has increases to $this->speed".PHP_EOL;
  }

  public function speedDown(int $decrement)
  {
    if (($this->speed - $decrement) >= 0)
    {
      $this->speed -= $decrement;
    }
    else
    {
      $this->speed = 0;
    }
    echo "Speed has decreased to $this->speed".PHP_EOL;
  }

  // alias
  function applyBrakes(int $decrement) {
    $this->speedDown($decrement);
  }

  public abstract function getInfo();

  public abstract function drive();

}
