# Vehicle - Bicycle

1. Different vehicle instances are created using respective builder class (Builder pattern)

2. There is a vehicle builder factory to create builder instance using type

3. There is a bicycle assembly line for different types of bicycle using decorator (Decorator pattern)

4. php v7.x

5. To test run:
  ```php
  php VehicleTest.php
  ```

6. interface VehicleInterface -> abstract Vehicle -> concrete vehicle classes (Bicycle, Car, Truck)

7. abstract Part -> concrete part classes (Engine, Wheel, Door)

8. interface BuilderInterface -> concrete builder classes (BicycleBuilder, CarBuilder, TruckBuilder)

9. Director (to create vehicle)

10. BicycleDecorator (to assemble different bike - Sports, Hybrid)
