<?php

namespace Company;

include_once 'FactoryMethod.php';
include_once 'CarBuilder.php';
include_once 'TruckBuilder.php';
include_once 'BicycleBuilder.php';
include_once 'BuilderInterface.php';

use Company\FactoryMethod;
use Company\CarBuilder;
use Company\TruckBuilder;
use Company\BicycleBuilder;
use Company\BuilderInterface;

class VehicleBuilderFactory extends FactoryMethod
{
  public function createVehicle(string $type): BuilderInterface
  {
    switch ($type) {
      case parent::CAR:
        return new CarBuilder();
      case parent::TRUCK:
        return new TruckBuilder();
      case parent::BICYCLE:
        return new BicycleBuilder();
      default:
        throw new InvalidArgumentException("$type is not a valid vehicle");
    }
  }
}
