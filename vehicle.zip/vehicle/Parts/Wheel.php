<?php

namespace Company\Parts;

include_once 'Part.php';

use Company\Parts\Part;

class Wheel extends Part
{
  private $type;      // Steel, Alloy, Forged
  private $diameter;  //

  function __construct() {		
    $this->name = 'Wheel';
  }

  /**
   * @param void
   * @return string
   */
  public function getType() {
    return $this->type;
  }

  /**
   * @param string $type
   * @return void
   */
  public function setType(string $type) {
    $this->type = $type;
  }

  /**
   * @param void
   * @return int
   */
  public function getDiameter() {
    return $this->diameter;
  }

  /**
   * @param float $diameter
   * @return void
   */
  public function setDiameter(float $diameter) {
    $this->diameter = $diameter;
  }
}
