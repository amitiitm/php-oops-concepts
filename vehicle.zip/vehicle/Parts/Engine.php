<?php

namespace Company\Parts;

include_once 'Part.php';

use Company\Parts\Part;

class Engine extends Part
{
  private $type;      // Fuel, Electric
  private $stroke;    // Two, Four

  function __construct() {		
    $this->name = 'Engine';
  }

  /**
   * @param void
   * @return string
   */
  public function getType() {
    return $this->type;
  }

  /**
   * @param string $type
   * @return void
   */
  public function setType(string $type) {
    $this->type = $type;
  }

  /**
   * @param void
   * @return int
   */
  public function getStroke() {
    return $this->stroke;
  }

  /**
   * @param int $stroke
   * @return void
   */
  public function setStroke(string $stroke) {
    $this->stroke = $stroke;
  }
}
