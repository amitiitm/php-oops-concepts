<?php

namespace Company\Parts;

abstract class Part
{
  /**
   * @var string
   */
  protected $name;

  public function getName()
  {
    return $this->name;
  }
}
