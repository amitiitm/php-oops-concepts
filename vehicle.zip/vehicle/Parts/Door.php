<?php

namespace Company\Parts;

include_once 'Part.php';

use Company\Parts\Part;

class Door extends Part
{
  private $type;      // Scissor, Gullwing, Canopy, Sliding, ...
  private $window;    // Power, Manual

  function __construct() {		
    $this->name = 'Door';
  }

  /**
   * @param void
   * @return string
   */
  public function getType() {
    return $this->type;
  }

  /**
   * @param string $type
   * @return void
   */
  public function setType(string $type) {
    $this->type = $type;
  }

  /**
   * @param void
   * @return string
   */
  public function getWindow() {
    return $this->window;
  }

  /**
   * @param string $window
   * @return void
   */
  public function setWindow(string $window) {
    $this->window = $window;
  }
}
