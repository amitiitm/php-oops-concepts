<?php

namespace Company;

include_once 'Bicycle.php';
include_once 'Parts/Part.php';
include_once 'Parts/Door.php';
include_once 'Parts/Wheel.php';
include_once 'Parts/Engine.php';
include_once 'BuilderInterface.php';

use Company\Bicycle;
use Company\Parts\Part;
use Company\Parts\Door;
use Company\Parts\Wheel;
use Company\Parts\Engine;
use Company\BuilderInterface;

class BicycleBuilder implements BuilderInterface
{
  /**
   * @var Bicycle
   */
  private $bicycle;

  function __construct() {		
    $this->createVehicle();
  }

  public function addColor(string $rgb) {
    $this->bicycle->setColor($rgb);
    return $this;
  }

  public function addChasisNumber(string $chasisNumber) {
    $this->bicycle->setChasisNumber($chasisNumber);
    return $this;
  }

  public function addDoors()
  {
    $this->bicycle->setPart('noDoor', new Parts\Door());
  }

  public function addEngine()
  {
    $this->bicycle->setPart('noEngine', new Parts\Engine());
  }

  public function addWheel()
  {
    $this->bicycle->setPart('wheelF', new Parts\Wheel());
    $this->bicycle->setPart('wheelR', new Parts\Wheel());
  }

  public function createVehicle()
  {
    $this->bicycle = new Bicycle();
  }

  public function getVehicle(): Vehicle
  {
    return $this->bicycle;
  }
}
