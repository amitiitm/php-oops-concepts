<?php

namespace Company;

include_once 'Director.php';
include_once 'Parts/Part.php';
include_once 'Parts/Wheel.php';
include_once 'VehicleBuilderFactory.php';
include_once 'SportBicycleDecorator.php';
include_once 'HybridBicycleDecorator.php';

use Company\Director;
use Company\Parts\Part;
use Company\Parts\Wheel;
use Company\VehicleBuilderFactory;
use Company\SportBicycleDecorator;
use Company\HybridBicycleDecorator;

$bicycleBuilder = (new VehicleBuilderFactory())
                    ->createVehicle('bicycle')
                    ->addColor('black')
                    ->addChasisNumber('12345');

$bicycle = (new Director())->build($bicycleBuilder);

// operations
$bicycleBuilder = (new VehicleBuilderFactory())
                    ->createVehicle('bicycle')
                    ->addColor('red')
                    ->addChasisNumber('12346');

$bicycle = (new Director())->build($bicycleBuilder);

$wheelF = $bicycle->getPart('wheelF');
$wheelF->setType('allow');
$wheelF->setDiameter(2);

$wheelR = $bicycle->getPart('wheelF');
$wheelR->setType('allow');
$wheelR->setDiameter(2.2);

$bicycle->setPart('wheelF', $wheelF);
$bicycle->setPart('wheelR', $wheelR);

$bicycleDecorator = new BicycleDecorator($bicycle);

$sportBicycle = new SportBicycleDecorator($bicycleDecorator);
$sportBicycle->assemble();

$hybridBicycle = new HybridBicycleDecorator($bicycleDecorator);
$hybridBicycle->assemble();

$bicycle->drive();
$bicycle->speedUp(10);
$bicycle->speedDown(5);
$bicycle->speedUp(10);
$bicycle->speedDown(5);
