<?php

namespace Company;


include_once 'Bicycle.php';
include_once 'BicycleDecorator.php';

use Company\Bicycle;
use Company\BicycleDecorator;

class SportBicycleDecorator extends BicycleDecorator
{
  /**
   * @var Bicycle
   */
  private $sportBicycle;

  function __construct(BicycleDecorator $bicycle)
  {		
    $this->sportBicycle = $bicycle;
  }

  public function assemble()
  {
    echo "Adding sport bike parts...".PHP_EOL;
    // $this->bicycle->setParts('gears', new Gear());
  }
}
