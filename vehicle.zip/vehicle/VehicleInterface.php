<?php

namespace Company;

interface VehicleInterface
{
  public function setColor(string $rgb);
}
