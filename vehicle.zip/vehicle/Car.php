<?php

namespace Company;

include_once 'Vehicle.php';

use Company\Vehicle;

class Car extends Vehicle
{
  function __construct() {		
    $this->topSpeed = 120;
  }

  public function getInfo()
  {
    var_dump($this);
  }

  public function drive()
  {
    echo "Driving car ...".PHP_EOL;
  }
}
