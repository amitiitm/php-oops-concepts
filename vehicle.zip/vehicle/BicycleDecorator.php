<?php

namespace Company;

include_once 'Bicycle.php';

use Company\Bicycle;

class BicycleDecorator
{
  /**
   * @var Bicycle
   */
  protected $bicycle;

  function __construct(Bicycle $bicycle)
  {
    $this->bicycle = $bicycle;
    $this->assemble();
  }

  public function assemble()
  {
    echo "Basic bicycle...".PHP_EOL;
  }
}
