<?php

namespace Company;

include_once 'Car.php';
include_once 'Parts/Door.php';
include_once 'Parts/Wheel.php';
include_once 'Parts/Engine.php';
include_once 'BuilderInterface.php';

use Company\Car;
use Company\Parts\Door;
use Company\Parts\Wheel;
use Company\Parts\Engine;
use Company\BuilderInterface;

class CarBuilder implements BuilderInterface
{
  /**
   * @var Car
   */
  private $car;

  function __construct() {		
    $this->createVehicle();
  }

  public function addColor(string $rgb) {
    $this->car->setColor($rgb);
    return $this;
  }

  public function addChasisNumber(string $chasisNumber) {
    $this->bicycle->setChasisNumber($chasisNumber);
    return $this;
  }

  public function addDoors()
  {
    $this->car->setPart('rightDoor', new Parts\Door());
    $this->car->setPart('leftDoor', new Parts\Door());
    $this->car->setPart('trunkLid', new Parts\Door());
  }

  public function addEngine()
  {
    $this->car->setPart('engine', new Parts\Engine());
  }

  public function addWheel()
  {
    $this->car->setPart('wheelLF', new Parts\Wheel());
    $this->car->setPart('wheelRF', new Parts\Wheel());
    $this->car->setPart('wheelLR', new Parts\Wheel());
    $this->car->setPart('wheelRR', new Parts\Wheel());
  }

  public function createVehicle()
  {
    $this->car = new Parts\Car();
  }

  public function getVehicle(): Vehicle
  {
    return $this->car;
  }
}
