<?php

namespace Company;

include_once 'Vehicle.php';

use Company\Vehicle;

class Director
{
  public function build(BuilderInterface $builder): Vehicle
  {
    $builder->addDoors();
    $builder->addEngine();
    $builder->addWheel();

    return $builder->getVehicle();
  }
}
