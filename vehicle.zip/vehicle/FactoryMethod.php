<?php

namespace Company;

abstract class FactoryMethod
{
  const CAR = 'car';
  const TRUCK = 'truck';
  const BICYCLE = 'bicycle';

  abstract protected function createVehicle(string $type);
}
