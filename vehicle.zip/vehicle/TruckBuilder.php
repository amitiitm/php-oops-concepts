<?php

namespace Company;

include_once 'Truck.php';
include_once 'Parts/Door.php';
include_once 'Parts/Wheel.php';
include_once 'Parts/Engine.php';
include_once 'BuilderInterface.php';

use Company\Truck;
use Company\Parts\Door;
use Company\Parts\Wheel;
use Company\Parts\Engine;
use Company\BuilderInterface;

class TruckBuilder implements BuilderInterface
{
  /**
   * @var Truck
   */
  private $truck;

  function __construct() {		
    $this->createVehicle();
  }

  public function addColor(string $rgb) {
    $this->truck->setColor($rgb);
    return $this;
  }

  public function addChasisNumber(string $chasisNumber) {
    $this->bicycle->setChasisNumber($chasisNumber);
    return $this;
  }

  public function addDoors()
  {
    $this->truck->setPart('rightDoor', new Parts\Door());
    $this->truck->setPart('leftDoor', new Parts\Door());
  }

  public function addEngine()
  {
    $this->truck->setPart('truckEngine', new Parts\Engine());
  }

  public function addWheel()
  {
    $this->truck->setPart('wheel1', new Parts\Wheel());
    $this->truck->setPart('wheel2', new Parts\Wheel());
    $this->truck->setPart('wheel3', new Parts\Wheel());
    $this->truck->setPart('wheel4', new Parts\Wheel());
    $this->truck->setPart('wheel5', new Parts\Wheel());
    $this->truck->setPart('wheel6', new Parts\Wheel());
  }

  public function createVehicle()
  {
    $this->truck = new Parts\Truck();
  }

  public function getVehicle(): Vehicle
  {
    return $this->truck;
  }
}
