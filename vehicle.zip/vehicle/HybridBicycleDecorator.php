<?php

namespace Company;


include_once 'Bicycle.php';
include_once 'BicycleDecorator.php';

use Company\Bicycle;
use Company\BicycleDecorator;

class HybridBicycleDecorator extends BicycleDecorator
{
  /**
   * @var BicycleDecorator
   */
  private $hybridBicycle;

  function __construct(BicycleDecorator $bicycle)
  {		
    $this->hybridBicycle = $bicycle;
  }

  public function assemble()
  {
    echo "Adding hybrid bike parts...".PHP_EOL;
    // $this->bicycle->setParts('gears', new Gear());
    // $this->bicycle->setParts('hydrolics', new Hydrolic());
  }
}
