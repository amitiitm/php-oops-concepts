<?php

namespace Company;

include_once 'Vehicle.php';

use Company\Vehicle;

class Truck extends Vehicle
{
  function __construct() {		
    $this->topSpeed = 60;
  }

  public function getInfo()
  {
    var_dump($this);
  }

  public function drive()
  {
    echo "Driving truck ...".PHP_EOL;
  }
}
